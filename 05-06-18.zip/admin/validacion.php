<?php
function validacion(){
	if($_SESSION['log_user_id']=='44' & $_SESSION['user_email'] == 'manuelperez.0000@gmail.com' & $_SESSION['user_dni'] == '20853601'){
		return true;
	}else{
		return false;
	}
}
if (validacion()==true){
	  echo '<li class="nav-item">
				<a href="admin1.php" class="btn btn-danger btn-sm"> Taza </a>
	  		</li>';
}


?>
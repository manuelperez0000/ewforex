<?php
header("location: useradmin.php");
?>
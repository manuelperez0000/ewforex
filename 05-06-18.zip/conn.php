<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ewforex";
/*
$servername = "localhost";
$username = "ewforexuser";
$password = "123ew321";
$dbname = "ewforex";
*/
?>
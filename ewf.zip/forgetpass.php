<?php
header('Cache-Control: no cache');
session_cache_limiter('private_no_expire');
session_start();
require_once('conn.php');
$email = $_POST['email'];
$mysqli=mysqli_connect($servername,$username,$password,$dbname);
$query = "SELECT * FROM users WHERE correo='$email'"; 
$result = mysqli_query($mysqli,$query)or die(mysqli_error());
$row=mysqli_fetch_array($result);
if($row['correo']== true){
	
	echo "<script>alert('Le enviaremos a su correo un link para recuperar su contraseña');</script>";
	$clave="hola123";
	$direccion = $row['correo'];
	$titulo = "Recuperacion de clave ewforex.net";
	$mensaje = "Su clave es: ".$clave;
	mail($direccion,$titulo,$mensaje);
	
}else{
	echo "<script>alert('El correo ingresado no existe en nuestra base de datos');</script>";
}
echo '<br>';

echo $email = $_POST["email"];
?>


<?php
$servername = "localhost";
$username = "ewforexuser";
$password = "123ew321";
$dbname = "ewforex";
?>
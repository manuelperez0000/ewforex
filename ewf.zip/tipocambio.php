<?php
$compra = 3.25;
$venta = 3.28;
$_SESSION['compra']= $compra;
$_SESSION['venta']= $venta;

?>